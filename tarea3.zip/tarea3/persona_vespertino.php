<?php

//Definir la clase persona
class persona  {

     //Definir propiedades
	public $calif1;
	public $calif2;
	public $calif3;

	//Definir método obtención de datos
	//getters

	public function getCalif1(){
		return $this->calif1;
	}
	public function getCalif2(){
		return $this->calif2;
	}
    public function getCalif3(){
    	return $this->calif3;
    }

    //Definir Métodos asignación de datos
    //setters

    public function setCalif1($valor){
    	$this->calif1=$valor;
    }

    public function setCalif2($valor){
    	$this->calif2=$valor;
    }
    public function setCalif3($valor){
    	$this->calif3=$valor;
    }

    //Método de cálculo de IMC acediendo a las propiedaades

    public function prom(){
    	return ($this->calif1 + $this->calif2 + $this->calif3) / 3;
    }
    //Calcula el IMC mediante el metodo get

    public function imc2(){
    	return $this->getPeso() / ($this->getAltura() * $this->getAltura());
    }

}

?>