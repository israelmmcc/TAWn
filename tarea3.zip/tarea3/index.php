<?php

//Incluir la clase
include "persona_vespertino.php";

//Instanciar la clase
$persona = new persona(1);

//Asignar valores a las propiedades del objeto
echo"Alumno 1 <br>";
$persona->setCalif1(60);
$persona->setCalif2(100);
$persona->setCalif3(60);
$alumno1 = array ("Unidad 1"=>$persona->calif1, "Unidad 2" =>$persona->calif2, "Unidad3"=>$persona->calif3);
arsort($alumno1);
//Impresiones de los resultados
foreach ($alumno1 as $key => $val){
	echo $key ."=" . $val . "<br>";
}
if ($persona->calif1 <= 60 or$persona->calif2 <= 60 or $persona->calif3 <= 60 ){
	echo"Promedio: 60";
} 
else{
echo"Promedio: ".$persona->prom();
}
echo"<br><br>";
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////1
$persona = new persona(2);

//Asignar valores a las propiedades del objeto
echo"Alumno 2 <br>";
$persona->setCalif1(80);
$persona->setCalif2(77);
$persona->setCalif3(80);
$alumno2 = array ("Unidad 1"=>$persona->calif1, "Unidad 2" =>$persona->calif2, "Unidad3"=>$persona->calif3);
arsort($alumno2);
//Impresiones de los resultados
foreach ($alumno2 as $key => $val){
	echo $key ."=" . $val . "<br>";
}
if ($persona->calif1 <= 60 or$persona->calif2 <= 60 or $persona->calif3 <= 60 ){
	echo"Promedio: 60";
} 
else{
echo"Promedio: ".$persona->prom();
}
echo"<br><br>";
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////2
$persona = new persona(3);

//Asignar valores a las propiedades del objeto
echo"Alumno 3 <br>";
$persona->setCalif1(80);
$persona->setCalif2(90);
$persona->setCalif3(74);
$alumno3 = array ("Unidad 1"=>$persona->calif1, "Unidad 2" =>$persona->calif2, "Unidad3"=>$persona->calif3);
arsort($alumno3);
//Impresiones de los resultados
foreach ($alumno3 as $key => $val){
	echo $key ."=" . $val . "<br>";
}
if ($persona->calif1 <= 60 or$persona->calif2 <= 60 or $persona->calif3 <= 60 ){
	echo"Promedio: 60";
} 
else{
echo"Promedio: ".$persona->prom();
}
echo"<br><br>";
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////3
$persona = new persona(4);

//Asignar valores a las propiedades del objeto
echo"Alumno 4 <br>";
$persona->setCalif1(71);
$persona->setCalif2(90);
$persona->setCalif3(75);
$alumno4 = array ("Unidad 1"=>$persona->calif1, "Unidad 2" =>$persona->calif2, "Unidad3"=>$persona->calif3);
arsort($alumno4);
//Impresiones de los resultados
foreach ($alumno4 as $key => $val){
	echo $key ."=" . $val . "<br>";
}
if ($persona->calif1 <= 60 or$persona->calif2 <= 60 or $persona->calif3 <= 60 ){
	echo"Promedio: 60";
} 
else{
echo"Promedio: ".$persona->prom();
}
echo"<br><br>";
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////4
$persona = new persona(5);

//Asignar valores a las propiedades del objeto
echo"Alumno 5 <br>";
$persona->setCalif1(80);
$persona->setCalif2(90);
$persona->setCalif3(80);
$alumno5 = array ("Unidad 1"=>$persona->calif1, "Unidad 2" =>$persona->calif2, "Unidad3"=>$persona->calif3);
arsort($alumno5);
//Impresiones de los resultados
foreach ($alumno5 as $key => $val){
	echo $key ."=" . $val . "<br>";
}
if ($persona->calif1 <= 60 or$persona->calif2 <= 60 or $persona->calif3 <= 60 ){
	echo"Promedio: 60";
} 
else{
echo"Promedio: ".$persona->prom();
}
echo"<br><br>";
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////5
$persona = new persona(6);

//Asignar valores a las propiedades del objeto
echo"Alumno 6 <br>";
$persona->setCalif1(88);
$persona->setCalif2(91);
$persona->setCalif3(60);
$alumno6 = array ("Unidad 1"=>$persona->calif1, "Unidad 2" =>$persona->calif2, "Unidad3"=>$persona->calif3);
arsort($alumno6);
//Impresiones de los resultados
foreach ($alumno6 as $key => $val){
	echo $key ."=" . $val . "<br>";
}
if ($persona->calif1 <= 60 or$persona->calif2 <= 60 or $persona->calif3 <= 60 ){
	echo"Promedio: 60";
} 
else{
echo"Promedio: ".$persona->prom();
}
echo"<br><br>";
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////6
$persona = new persona(7);

//Asignar valores a las propiedades del objeto
echo"Alumno 7 <br>";
$persona->setCalif1(79);
$persona->setCalif2(85);
$persona->setCalif3(94);
$alumno7 = array ("Unidad 1"=>$persona->calif1, "Unidad 2" =>$persona->calif2, "Unidad3"=>$persona->calif3);
arsort($alumno7);
//Impresiones de los resultados
foreach ($alumno7 as $key => $val){
	echo $key ."=" . $val . "<br>";
}
if ($persona->calif1 <= 60 or$persona->calif2 <= 60 or $persona->calif3 <= 60 ){
	echo"Promedio: 60";
} 
else{
echo"Promedio: ".$persona->prom();
}
echo"<br><br>";
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////7
$persona = new persona(8);

//Asignar valores a las propiedades del objeto
echo"Alumno 8 <br>";
$persona->setCalif1(74);
$persona->setCalif2(71);
$persona->setCalif3(80);
$alumno8 = array ("Unidad 1"=>$persona->calif1, "Unidad 2" =>$persona->calif2, "Unidad3"=>$persona->calif3);
arsort($alumno8);
//Impresiones de los resultados
foreach ($alumno8 as $key => $val){
	echo $key ."=" . $val . "<br>";
}
if ($persona->calif1 <= 60 or$persona->calif2 <= 60 or $persona->calif3 <= 60 ){
	echo"Promedio: 60";
} 
else{
echo"Promedio: ".$persona->prom();
}
echo"<br><br>";
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8
$persona = new persona(9);

//Asignar valores a las propiedades del objeto
echo"Alumno 9 <br>";
$persona->setCalif1(60);
$persona->setCalif2(93);
$persona->setCalif3(100);
$alumno9 = array ("Unidad 1"=>$persona->calif1, "Unidad 2" =>$persona->calif2, "Unidad3"=>$persona->calif3);
arsort($alumno9);
//Impresiones de los resultados
foreach ($alumno9 as $key => $val){
	echo $key ."=" . $val . "<br>";
}
if ($persona->calif1 <= 60 or$persona->calif2 <= 60 or $persona->calif3 <= 60 ){
	echo"Promedio: 60";
} 
else{
echo"Promedio: ".$persona->prom();
}
echo"<br><br>";
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////9
$persona = new persona(10);

//Asignar valores a las propiedades del objeto
echo"Alumno 10 <br>";
$persona->setCalif1(74);
$persona->setCalif2(88);
$persona->setCalif3(71);
$alumno10 = array ("Unidad 1"=>$persona->calif1, "Unidad 2" =>$persona->calif2, "Unidad3"=>$persona->calif3);
arsort($alumno10);
//Impresiones de los resultados
foreach ($alumno10 as $key => $val){
	echo $key ."=" . $val . "<br>";
}
if ($persona->calif1 <= 60 or$persona->calif2 <= 60 or $persona->calif3 <= 60 ){
	echo"Promedio: 60";
} 
else{
echo"Promedio: ".$persona->prom();
}
echo"<br><br>";
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////10
?>