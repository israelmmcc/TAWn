<?php
#Salir si alguno de los datos no está presente
if(!isset($_POST["empleado"]) || !isset($_POST["carrera"]) || !isset($_POST["nombre"]) || !isset($_POST["telefono"])) exit();

#Si todo va bien, se ejecuta esta parte del código...

include "base_de_datos.php";
$empleado = $_POST["empleado"];
$carrera = $_POST["carrera"];
$nombre = $_POST["nombre"];
$telefono = $_POST["telefono"];

/*
	Al incluir el archivo "base_de_datos.php", todas sus variables están
	a nuestra disposición. Por lo que podemos acceder a ellas tal como si hubiéramos
	copiado y pegado el código
*/
$sentencia = $base_de_datos->prepare("INSERT INTO maestros(empleado, carrera, nombre, telefono) VALUES (?, ?, ?, ?);");
$resultado = $sentencia->execute([$empleado, $carrera, $nombre, $telefono]); # Pasar en el mismo orden de los ?

#execute regresa un booleano. True en caso de que todo vaya bien, falso en caso contrario.
#Con eso podemos evaluar

if($resultado === TRUE) echo "<b>Insertado correctamente</b>";
else echo "Algo salió mal. Por favor verifica que la tabla exista";


?>