<?php
include_once('db/database_utilities.php');

$t=$_GET['t'];
//Se revisa que las variables nombre y email se esten recibiendo mediante el metodo POST para despues continuar
//con la insercion de los valores ingresados en la base de datos, para finalmente redireccionar al inicio
if(isset($_POST['id']) && isset($_POST['nombre']) && isset($_POST['apellidos']) && isset($_POST['telefono'])&& isset($_POST['email']) && isset($_POST['direccion'])){
  add($_POST['id'],$_POST['nombre'],$_POST['apellidos'],$_POST['telefono'],$_POST['email'],$_POST['direccion'],$t);
  header("location: listado.php?t=".$_GET['t']."");
}
?>
<!doctype html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Nuevo Cliente</title>
    <link rel="stylesheet" href="./css/foundation.css" />
  </head>
  <body>


    <div class="row">
       <div class="large-9 columns">
        <h3>Agregar Nuevo Cliente</h3>
        <br>
        <div class="section-container tabs" data-section>
          <section class="section">
            <div class="content" data-slug="panel1">
                <form method="POST" action="add.php?t=<?php echo($t)?>">
                  <label for="id">ID:</label>
                  <input type="text" name="id"><br>
                  <label for="nombre">Nombre:</label>
                  <input type="text" name="nombre"><br>
                  <label for="apellidos">Apellidos:</label>
                  <input type="text" name="apellidos"><br>
                  <label for="telefono">Teléfono:</label>
                  <input type="text" name="telefono"><br>
                  <label for="email">Email:</label>
                  <input type="text" name="email"><br>
                   <label for="direccion">Dirección:</label>
                  <input type="text" name="direccion"><br>
                  <button type="submit" class="success">Guardar</button>
                   <td><a href="./listado.php?t=<?php echo($t) ?>" class="button radius tiny success">Regresar</a></td>
                </form>

            </div>
          </section>
        </div>
      </div>
    </div>
     
    