<?php
  require_once("db/database_utilities.php");
?>
<!doctype html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Clientes</title>
    <link rel="stylesheet" href="./css/foundation.css" />

  </head>
  <body>
   <center>
                <td><a href="./listado.php?t=1" class="button radius success">Listado de Clientes</a></td>
              </center>



