<?php
#Salir si alguno de los datos no está presente
if(!isset($_POST["edad"]) || !isset($_POST["altura"]) || !isset($_POST["peso"])) exit();

#Si todo va bien, se ejecuta esta parte del código...

include "base_de_datos.php";
$edad = $_POST["edad"];
$altura = $_POST["altura"];
$peso = $_POST["peso"];
$imc = $peso /($altura*$altura);

/*
	Al incluir el archivo "base_de_datos.php", todas sus variables están
	a nuestra disposición. Por lo que podemos acceder a ellas tal como si hubiéramos
	copiado y pegado el código
*/
$sentencia = $base_de_datos->prepare("INSERT INTO imc(edad, altura, peso) VALUES (?, ?, ?);");
$resultado = $sentencia->execute([$edad, $altura, $peso]); # Pasar en el mismo orden de los ?

#execute regresa un booleano. True en caso de que todo vaya bien, falso en caso contrario.
#Con eso podemos evaluar

if($resultado === TRUE) echo "<b>Insertado correctamente</b>";
else echo "Algo salió mal. Por favor verifica que la tabla exista";
echo "<br> <br>";
//Imprimir los datos ingresados a la base de datos

echo "Edad : <b> $edad </b><br>";
echo "Altura : <b> $altura<br> </b>";
echo "Peso : <b> $peso <br></b>";
echo "IMC : <b> $imc <br></b>";


?>

