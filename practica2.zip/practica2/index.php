<?php

//Incluir la clase
include "persona_vespertino.php";
//Instanciar la clase
$persona = new persona();

//Asignar valores a las propiedades del objeto
?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Registrar persona</title>
</head>
<body>
	//Creación del formulario
	<form method="post" action="nuevaPersona.php">
		<label for="edad">Edad:</label>
		<br>
		<input name="edad" required type="text" id="edad" placeholder="Escribe tu edad...">
		<br><br>

		<label for="altura">Altura:</label>
		<br>
		<input name="altura" required type="text" id="altura" placeholder="Escribe tu altura...">
		<br><br>
       
       	<label for="peso">Peso:</label>
		<br>
		<input name="peso" required type="text" id="peso" placeholder="Escribe tu peso...">
		<br><br>
		<br><br><input type="submit" value="Registrar">
	</form>


</body>
</html>

